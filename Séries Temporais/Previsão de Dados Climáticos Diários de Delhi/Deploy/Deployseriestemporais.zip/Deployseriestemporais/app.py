from flask import Flask, render_template, request
import pandas as pd
from prophet import Prophet
import joblib
import matplotlib.pyplot as plt
import os

app = Flask(__name__)

# Carregando o modelo treinado
try:
    modelo = joblib.load('modelo_prophet.pkl')
    print("Modelo carregado com sucesso.")
except Exception as e:
    print(f"Erro ao carregar o modelo: {e}")

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Coletando dados do formulário
        data_input = request.form.get('data_input')
        humidity = float(request.form.get('humidity'))
        wind_speed = float(request.form.get('wind_speed'))
        print(f"Dados recebidos - Data: {data_input}, Umidade: {humidity}, Velocidade do Vento: {wind_speed}")

        # Preparando os dados para o Prophet
        future_data = pd.DataFrame({
            'ds': pd.date_range(start=data_input, periods=30, freq='D'),
            'humidity': [humidity] * 30,
            'wind_speed': [wind_speed] * 30
        })

        # Fazendo previsão
        forecast = modelo.predict(future_data)
        print("Previsão realizada com sucesso.")

        # Criando o gráfico
        plt.figure(figsize=(10, 5))
        plt.plot(forecast['ds'], forecast['yhat'], label='Previsão', color='blue')
        plt.fill_between(forecast['ds'], forecast['yhat_lower'], forecast['yhat_upper'], color='blue', alpha=0.2)
        plt.title('Previsão de Temperatura')
        plt.xlabel('Data')
        plt.ylabel('Temperatura')
        plt.legend()

        # Salvando o gráfico
        plot_path = 'static/forecast_plot.png'
        plt.savefig(plot_path)
        plt.close()
        print("Gráfico salvo em:", plot_path)

        return render_template('index.html', plot_url=plot_path)
    except Exception as e:
        print(f"Erro durante a previsão: {e}")
        return render_template('index.html', error=str(e))

if __name__ == '__main__':
    app.run(debug=True)
