from flask import Flask, request, jsonify
import joblib
import numpy as np
from flask_cors import CORS

# Carrega o modelo treinado
model = joblib.load('modellog.pkl')

app = Flask(__name__)
CORS(app)  # Permite requisições de diferentes origens

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json(force=True)

    # Verifica se todos os campos estão presentes
    if len(data) != 9:
        return jsonify({"error": "Precisamos de 9 variáveis!"}), 400

    try:
        features = np.array([[data['Estado'], data['Genero'], data['Idade'],
                              data['Patrimonio'], data['Saldo'], data['Produtos'],
                              data['TemCartCredito'], data['Ativo'], data['Salario']]], dtype=float)

        prediction = model.predict(features)
        return jsonify({'prediction': prediction.tolist()}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
