from flask import Flask, request, jsonify, render_template
import joblib
import numpy as np
from flask_cors import CORS

model = joblib.load('modelo_churn.pkl')
app = Flask(__name__)
CORS(app)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json(force=True)

    if len(data) != 10:
        return jsonify({"error": "Precisamos de 10 variáveis!"}), 400

    try:
        features = np.array([[data['CreditScore'], data['Geography'], data['Gender'],
                              data['Age'], data['Tenure'], data['Balance'],
                              data['NumOfProducts'], data['HasCrCard'],
                              data['IsActiveMember'], data['EstimatedSalary']]], dtype=float)

        prediction = model.predict(features)
        result = 'Saiu' if prediction[0] == 1 else 'Não saiu'
        return jsonify({'prediction': result}), 200
    except Exception as e:
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    app.run(debug=True)
